﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WarehouseMS
{
    class Globals
    {
        public static AllValidations Validator = new AllValidations();
    }
}
