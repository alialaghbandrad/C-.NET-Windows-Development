﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MidtermEFPassport
{
    /// <summary>
    /// Interaction logic for AddEditDialog.xaml
    /// </summary>
    public partial class AddEditDialog : Window
    {
        PersonDbContext ctx;
        Person currPerson;
        public AddEditDialog()
        {
            try
            {
                InitializeComponent();
                ctx = new PersonDbContext();
                
            }
            catch (SystemException ex) // catch-all for EF, SQL and many other exceptions
            {
                Console.WriteLine(ex.StackTrace);
                MessageBox.Show("Fatal error: Database connection failed:\n" + ex.Message);
                Environment.Exit(1); // fatal error
            }
        }

        private void btSave_Click(object sender, RoutedEventArgs e)
        {
            string name = tbName.Text;
            if (!int.TryParse(tbAge.Text, out int age))
            {
                MessageBox.Show("Age invalid");
                return;
            }

            if (name.Length < 2 || name.Length > 20)
            {
                MessageBox.Show(this, "Name must be 2-20 characters long", "Input error", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            try
            {
                Person person = new Person { Name = name, Age = age };
                ctx.Persons.Add(person);
                ctx.SaveChanges();
                tbName.Text = "";
                tbAge.Text = "0";
                // refresh the list for database
                
            }
            catch (SystemException ex) // catch-all for EF, SQL and many other exceptions
            {
                Console.WriteLine(ex.StackTrace);
                MessageBox.Show("Database operation failed:\n" + ex.Message);
            }
            // _nameResult = name;
            DialogResult = true; // assing result and dismiss the dialog
        }
    }
}
