using System;
using System.Data.Entity;
using System.IO;
using System.Linq;

namespace MidtermEFPassport
{
    public class PersonDbContext : DbContext
    {
        const string DbName = "Database.mdf";
        static string DbPath = Path.Combine(Environment.CurrentDirectory, DbName);
        public PersonDbContext()
            : base($@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename={DbPath};Integrated Security=True;Connect Timeout=30")
        {
        }

        public virtual DbSet<Person> Persons { get; set; }
        public virtual DbSet<Passport> Passports { get; set; }
    }

    //public class MyEntity
    //{
    //    public int Id { get; set; }
    //    public string Name { get; set; }
    //}
}