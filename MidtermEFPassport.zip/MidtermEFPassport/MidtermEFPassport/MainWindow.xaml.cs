﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MidtermEFPassport
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        PersonDbContext ctx;
        internal int selectedIndex = 0;
        public MainWindow()
        {
            try
            {
                InitializeComponent();
                ctx = new PersonDbContext();
                lvPersonList.ItemsSource = (from t in ctx.Persons select t).ToList<Person>();
            }
            catch (SystemException ex) // catch-all for EF, SQL and many other exceptions
            {
                Console.WriteLine(ex.StackTrace);
                MessageBox.Show("Fatal error: Database connection failed:\n" + ex.Message);
                Environment.Exit(1); // fatal error
            }
        }

        private void miAddPerson_Click(object sender, RoutedEventArgs e)
        {
            AddEditDialog dlg = new AddEditDialog();
            dlg.Owner = this;

            if (dlg.ShowDialog() == true)
            {
                try
                {
                    string name = dlg.tbName.Text;
                    
                    Person person = new Person { Name = name };
                    ctx.Persons.Add(person);
                    ctx.SaveChanges();
                    lvPersonList.ItemsSource = (from t in ctx.Persons select t).ToList<Person>();

                    Console.WriteLine("Todo added.");

                }
                catch (SystemException ex)  // catch-all for EF, SQL and many other exceptions
                {
                    Console.WriteLine(ex.StackTrace);
                    MessageBox.Show("Database operation failed:\n" + ex.Message);
                }

            }
        }

        private void lvPersonList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (lvPersonList.SelectedItems.Count == 0) return;
            Person pr = (Person)lvPersonList.SelectedItem;
            PassportDialog dlg = new PassportDialog(pr);
            dlg.Owner = this;
            if (dlg.ShowDialog() == true) // confirmed
            {
                
            }
        }

        private void DeletePersonClick(object sender, RoutedEventArgs e)
        {
            if (lvPersonList.SelectedItems.Count == 0) return;
            Person td = (Person)lvPersonList.SelectedItem;
            

            // See if the user really wants to delete a Flight
            string msg = "Do you want to delete the person?\n" + td.ToString();
            MessageBoxResult result = MessageBox.Show(msg, "My App", MessageBoxButton.OKCancel, MessageBoxImage.Warning);
            if (result == MessageBoxResult.OK)
            {
                ctx.Persons.Remove(td);
                ctx.SaveChanges();
                lvPersonList.ItemsSource = (from t in ctx.Persons select t).ToList<Person>();
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (MessageBox.Show("Do you want to leave?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
            {
                e.Cancel = true;
            }
        }

        private void miExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
