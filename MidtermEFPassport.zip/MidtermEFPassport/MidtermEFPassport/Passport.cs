﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermEFPassport
{
    public class Passport
    {
        // [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(8)]
        public string PassportNo { get; set; }

        [Required]
        public byte[] Photo { get; set; }

        public virtual Person Person { get; set; }

        public override string ToString()
        {
            return $"{Id}, {PassportNo}";
        }
    }
}
